import tkinter as tk
from tkinter import messagebox
import os.path
import pickle

class codigoInvalido(Exception):
    pass


class Produto:

    def __init__(self, codigo, descricao, valorUnitario):
        self.__codigo = codigo
        self.__descricao = descricao
        self.__valorUnitario = valorUnitario

    def getCodigo(self):
        return self.__codigo
    
    def getDescricao(self):
        return self.__descricao

    def getValorUnitario(self):
        return self.__valorUnitario

class LimiteInsereProduto(tk.Toplevel):
    def __init__(self, controle):

        tk.Toplevel.__init__(self)
        self.geometry('250x100')
        self.title("Produto")
        self.controle = controle

        self.frameCodigo = tk.Frame(self)
        self.frameDescricao = tk.Frame(self)
        self.frameValorUnitario = tk.Frame(self)
        self.frameButton = tk.Frame(self)
        self.frameCodigo.pack()
        self.frameDescricao.pack()
        self.frameValorUnitario.pack()
        self.frameButton.pack()

        self.labelCodigo = tk.Label(self.frameCodigo,text="Código: ")
        self.labelDescricao = tk.Label(self.frameDescricao,text="Descrição: ")
        self.labelValorUnitario = tk.Label(self.frameValorUnitario,text="Valor Unitário: ")
        self.labelCodigo.pack(side="left")
        self.labelDescricao.pack(side="left")  
        self.labelValorUnitario.pack(side="left") 

        self.inputCodigo = tk.Entry(self.frameCodigo, width=20)
        self.inputCodigo.pack(side="left")
        self.inputDescricao = tk.Entry(self.frameDescricao, width=20)
        self.inputDescricao.pack(side="left") 
        self.inputValorUnitario = tk.Entry(self.frameValorUnitario, width=20)
        self.inputValorUnitario.pack(side="left")             

        self.buttonSubmit = tk.Button(self.frameButton ,text="Concluido")      
        self.buttonSubmit.pack(side="left")
        self.buttonSubmit.bind("<Button>", controle.enterHandler)

        self.buttonClear = tk.Button(self.frameButton ,text="Clear")      
        self.buttonClear.pack(side="left")
        self.buttonClear.bind("<Button>", controle.clearHandler)  

        self.buttonFecha = tk.Button(self.frameButton ,text="Fechar")      
        self.buttonFecha.pack(side="left")
        self.buttonFecha.bind("<Button>", controle.fechaHandler)

    def mostraJanela(self, titulo, msg):
        messagebox.showinfo(titulo, msg)

#Janela de consulta
class LimiteConsultaProduto(tk.Toplevel):
    def __init__(self, controle):

        tk.Toplevel.__init__(self)
        self.geometry('250x100')
        self.title("Produto")
        self.controle = controle

        self.frameCodigo = tk.Frame(self)
        self.frameButton = tk.Frame(self)
        self.frameCodigo.pack()
        self.frameButton.pack()

        self.labelCodigo = tk.Label(self.frameCodigo,text="Código: ")
        self.labelCodigo.pack(side="left") 
        self.inputCodigo = tk.Entry(self.frameCodigo, width=20)
        self.inputCodigo.pack(side="left")         
        self.buttonSubmit = tk.Button(self.frameButton ,text="Consultar")      
        self.buttonSubmit.pack(side="left")
        #Para realizar a busca
        self.buttonSubmit.bind("<Button>", controle.findHandler)

        self.buttonClear = tk.Button(self.frameButton ,text="Limpar")      
        self.buttonClear.pack(side="left")
        self.buttonClear.bind("<Button>", controle.clearHandlerFind)  

        self.buttonFecha = tk.Button(self.frameButton ,text="Fechar")      
        self.buttonFecha.pack(side="left")
        self.buttonFecha.bind("<Button>", controle.fechaHandlerFind)

    def mostraJanela(self, titulo, msg):
        messagebox.showinfo(titulo, msg)        

class LimiteMostraProduto():
    def __init__(self, str):
        messagebox.showinfo('Lista de Produtos', str)


class CtrlProduto():       
    def __init__(self, controlePrincipal):
        self.ctrlPrincipal = controlePrincipal

        if not os.path.isfile("produto.pickle"):
            self.listaProduto =  []
        else:
            with open("produto.pickle", "rb") as f:
                self.listaProduto = pickle.load(f)
    
    def salvaProdutos(self):
        if len(self.listaProduto) != 0:
            with open("produto.pickle","wb") as f:
                pickle.dump(self.listaProduto, f)

    def getProduto(self, codigo):
        estRet = None
        for est in self.listaProduto:
            if est.getCodigo() == codigo:
                estRet = est
        return estRet

    def getListaCodigo(self):
        listaCodigo = []
        for est in self.listaProduto:
            listaCodigo.append(est.getCodigo())
        return listaCodigo

    def insereProduto(self):
        self.limiteIns = LimiteInsereProduto(self) 

    def mostraProduto(self):
        self.limiteCons = LimiteConsultaProduto(self)

    def enterHandler(self, event):
        codigo = self.limiteIns.inputCodigo.get()
        descricao = self.limiteIns.inputDescricao.get()
        valorUnitario = self.limiteIns.inputValorUnitario.get()
        produto = Produto(codigo, descricao, valorUnitario)
        self.listaProduto.append(produto)
        self.limiteIns.mostraJanela('Sucesso', 'Produto cadastrado com sucesso')
        self.clearHandler(event)

    #Chama o consultar
    def consultaProduto(self):
        self.limiteCons= LimiteConsultaProduto(self)

    def findHandler(self, event):
        codigo = self.limiteCons.inputCodigo.get()
        i=0
        try:
            for prod in self.listaProduto:
                if prod.getCodigo()== codigo: i=1
            if i==0: raise codigoInvalido()

        except codigoInvalido:
            self.limiteCons.mostraJanela('Erro!', 'Código do produto não consta no banco de dados!')
            self.limiteCons.destroy()
        else: 
            string = ''
            for prod in self.listaProduto:
                if prod.getCodigo() == codigo:
                    string = 'Descricao. -- Valor Unitario\n'
                    string += prod.getDescricao() + ' -- ' + str(prod.getValorUnitario())+ '\n'
        LimiteMostraProduto(string)

    def clearHandler(self, event):
        self.limiteIns.inputCodigo.delete(0, len(self.limiteIns.inputCodigo.get()))
        self.limiteIns.inputDescricao.delete(0, len(self.limiteIns.inputDescricao.get()))
        self.limiteIns.inputValorUnitario.delete(0, len(self.limiteIns.inputValorUnitario.get()))

    def clearHandlerFind(self, event):
        self.limiteCons.inputCodigo.delete(0, len(self.limiteCons.inputCodigo.get()))       

    def fechaHandler(self, event):
        self.limiteIns.destroy()

    def fechaHandlerFind(self, event):
        self.limiteCons.destroy()
    
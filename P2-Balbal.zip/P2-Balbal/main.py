import tkinter as tk
from tkinter import messagebox
import produto as prod 
import cupom as cupom 

class LimitePrincipal():
    def __init__(self, root, controle):
        self.controle = controle
        self.root = root
        self.root.geometry('300x250')
        self.menubar = tk.Menu(self.root)        
        self.produtoMenu = tk.Menu(self.menubar)
        self.cupomMenu = tk.Menu(self.menubar)
        self.sairMenu = tk.Menu(self.\menubar)    

        self.produtoMenu.add_command(label="Insere", command=self.controle.insereProduto)
        self.produtoMenu.add_command(label="Consulta", command=self.controle.consultaProduto)
        self.menubar.add_cascade(label="Produto", menu=self.produtoMenu)

        self.cupomMenu.add_command(label="Insere", command=self.controle.insereCupom)
        self.cupomMenu.add_command(label="Consulta", command=self.controle.consultaCupom)        
        self.menubar.add_cascade(label="Cupom Fiscal", menu=self.cupomMenu)   

        self.sairMenu.add_command(label="Salva", command=self.controle.salvaDados)
        self.menubar.add_cascade(label="Sair", menu=self.sairMenu)     

        self.root.config(menu=self.menubar)

class ControlePrincipal():       
    def __init__(self):
        self.root = tk.Tk()

        self.ctrlProduto = prod.CtrlProduto(self)
        self.ctrlCupom = cupom.CtrlCupom(self)

        self.limite = LimitePrincipal(self.root, self) 

        self.root.title("Impressão de Cupons")

        self.root.mainloop()

    def insereProduto(self):
        self.ctrlProduto.insereProduto()

    def consultaProduto(self):
        self.ctrlProduto.consultaProduto()

    def insereCupom(self):
        self.ctrlCupom.insereCupom()

    def consultaCupom(self):
        self.ctrlCupom.consultaCupom()

    def salvaDados(self):
        self.ctrlProduto.salvaProdutos()
        self.ctrlCupom.salvaCupons()
        self.root.destroy()

if __name__ == '__main__':
    c = ControlePrincipal()
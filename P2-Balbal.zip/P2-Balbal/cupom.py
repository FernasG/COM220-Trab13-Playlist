import tkinter as tk
from tkinter import ttk
from tkinter import messagebox
import produto as prod 
import os.path
import pickle

class numeroCFInvalido(Exception):
    pass

class CupomFiscal:

    def __init__(self, numeroCF, nomeCliente, itensCupom):
        self.__numeroCF = numeroCF
        self.__nomeCliente = nomeCliente
        self.__itensCupom = itensCupom

    def getNumeroCF(self):
        return self.__numeroCF
    
    def getNomeCliente(self):
        return self.__nomeCliente

    def getItensCupom(self):
        return self.__itensCupom


class LimiteInsereCupom(tk.Toplevel):
    def __init__(self, controle, listaCod):

        tk.Toplevel.__init__(self)
        self.geometry('300x300')
        self.title("Cupom")
        self.controle = controle

        self.frameNumeroCF = tk.Frame(self)
        self.frameNomeCliente = tk.Frame(self)
        self.frameProduto = tk.Frame(self)
        self.frameButton = tk.Frame(self)
        self.frameNumeroCF.pack()
        self.frameNomeCliente.pack()
        self.frameProduto.pack()
        self.frameButton.pack()        

        self.labelNumeroCF = tk.Label(self.frameNumeroCF,text="Informe o código da Cupom Fiscal: ")
        self.labelNumeroCF.pack(side="left")
        self.inputNumeroCF = tk.Entry(self.frameNumeroCF, width=20)
        self.inputNumeroCF.pack(side="left")

        self.labelNomeCliente = tk.Label(self.frameNomeCliente,text="Informe o nome do Cliente: ")
        self.labelNomeCliente.pack(side="left")
        self.inputNomeCliente = tk.Entry(self.frameNomeCliente, width=20)
        self.inputNomeCliente.pack(side="left")

        self.labelProd = tk.Label(self.frameProduto,text="Escolha o produto: ")
        self.labelProd.pack(side="left") 
        self.listbox = tk.Listbox(self.frameProduto)
        self.listbox.pack(side="left")
        for codigo in listaCod:
            self.listbox.insert(tk.END, codigo)

        self.buttonInsere = tk.Button(self.frameButton ,text="Insere Produto")           
        self.buttonInsere.pack(side="left")
        self.buttonInsere.bind("<Button>", controle.insereProduto)

        self.buttonCria = tk.Button(self.frameButton ,text="Cria Cupom Fiscal")           
        self.buttonCria.pack(side="left")
        self.buttonCria.bind("<Button>", controle.criaCupom)    

    def mostraJanela(self, titulo, msg):
        messagebox.showinfo(titulo, msg)       

class LimiteConsultaCupom(tk.Toplevel):
    def __init__(self, controle):

        tk.Toplevel.__init__(self)
        self.geometry('300x250')
        self.title("Cupom Fiscal")
        self.controle = controle

        self.frameNumeroCF = tk.Frame(self)
        self.frameButton = tk.Frame(self)
        self.frameNumeroCF.pack()
        self.frameButton.pack()       

        self.labelNumeroCF = tk.Label(self.frameNumeroCF,text="Informe o Número da Cupom Fiscal: ")
        self.labelNumeroCF.pack(side="left")
        self.inputNumeroCF = tk.Entry(self.frameNumeroCF, width=20)
        self.inputNumeroCF.pack(side="left")
        self.buttonCria = tk.Button(self.frameButton ,text="Consultar")      
        self.buttonCria.pack(side="left")
        self.buttonCria.bind("<Button>", controle.findHandler)

        self.buttonClear = tk.Button(self.frameButton ,text="Limpar")      
        self.buttonClear.pack(side="left")
        self.buttonClear.bind("<Button>", controle.clearHandlerFind)  

        self.buttonFecha = tk.Button(self.frameButton ,text="Concluído")      
        self.buttonFecha.pack(side="left")
        self.buttonFecha.bind("<Button>", controle.fechaHandlerFind)    

    def mostraJanela(self, titulo, msg):
        messagebox.showinfo(titulo, msg) 

class LimiteMostraCupom():
    def __init__(self, str):
        messagebox.showinfo('Lista de Cupons Fiscais', str)

class CtrlCupom():       
    def __init__(self, controlePrincipal):
        self.ctrlPrincipal = controlePrincipal
        self.listaProdutos=[]
        if not os.path.isfile("cupom.pickle"):
            self.listaCupom =  []
        else:
            with open("cupom.pickle", "rb") as f:
                self.listaCupom = pickle.load(f)
    
    def salvaCupons(self):
        if len(self.listaCupom) != 0:
            with open("cupom.pickle","wb") as f:
                pickle.dump(self.listaCupom, f)

    def insereCupom(self):        
        listaCod = self.ctrlPrincipal.ctrlProduto.getListaCodigo()
        self.limiteIns = LimiteInsereCupom(self, listaCod)

    def criaCupom(self, event):
        numeroCF = self.limiteIns.inputNumeroCF.get()
        nomeCliente = self.limiteIns.inputNomeCliente.get()
        cupom = CupomFiscal(numeroCF, nomeCliente, self.listaProdutos)
        self.listaCupom.append(cupom)
        self.limiteIns.mostraJanela('Sucesso', 'Cupom Fiscal criada com sucesso')
        self.limiteIns.destroy()

    #Para a caixa de seleção
    def insereProduto(self, event):
        prodSel = self.limiteIns.listbox.get(tk.ACTIVE)
        produto = self.ctrlPrincipal.ctrlProduto.getProduto(prodSel)
        self.listaProdutos.append(produto)
        self.limiteIns.mostraJanela('Sucesso', 'Produto Inserido!')

    def consultaCupom(self):
        self.limiteCons= LimiteConsultaCupom(self)

    def findHandler(self, codigo):
        numeroCF = self.limiteCons.inputNumeroCF.get() 
        i=0
        total=0
        try:
            for cupom in self.listaCupom:
                if cupom.getNumeroCF()==numeroCF: i=1
            if i==0: raise numeroCFInvalido()

        except numeroCFInvalido:
            self.limiteCons.mostraJanela('Erro!', 'Numero da Cupom Fiscal não consta no banco de dados!')
            self.limiteCons.destroy()
        else: 
            string = ''
            for cupom in self.listaCupom:
                if cupom.getNumeroCF() == numeroCF:
                    string += 'Nome do cliente: ' + cupom.getNomeCliente() + '\n'
                    string += 'Nro Cupom: ' + cupom.getNumeroCF() + '\n'
                    string += '\n'
                    string += 'Itens:\n'

                for prod in cupom.getItensCupom():
                    string += str(prod.getCodigo()) + ' - ' + prod.getDescricao() + ' - ' + str(prod.getValorUnitario()) + '\n'
                    total += float(prod.getValorUnitario())
                string += '\n'
                string += 'Total do cupom: ' + str(total) + ' Reais' + '\n'
            LimiteMostraCupom(string)

#   Limpa Consultar
    def clearHandlerFind(self, event):
        self.limiteCons.inputNumeroCF.delete(0, len(self.limiteCons.inputNumeroCF.get()))
#   Fecha Consultar
    def fechaHandlerFind(self,event):
        self.limiteCons.destroy() 